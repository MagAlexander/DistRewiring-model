#!/bin/bash
#!/bin/bash
echo "Start simulation"
python optimisticSim.py espacio10x10.txt > trace10x10_optimistic-1.txt 
echo "Ends simulation"
echo "Data extraction begins"
python extractData.py trace10x10_optimistic-1.txt  traceOpt-1
echo "Data extraction ends"
