# This Python file uses the following encoding: utf-8
# Este archivo sirve de modelo para la creacion de aplicaciones, i.e. algoritmos concretos
# Autora: Magali Alexander López Chavira
# Version Diciembre-2014
# Nota261016: Este simulador implementa la Condición 0

""" Implementa la simulacion del modelo de creación de una red compleja con recableado, 
usando vecinos permanentes para evitar la desconexión de la red"""

import sys
from event import Event
from model import Model
#from process import Process
#from simulator import Simulator
from simulation import Simulation
import parametros
import funciones

class simulacionRecableado(Model):
    """ La clase simulacionRecableado desciende de la clase Model e implementa los metodos 
    "init()" y "receive()","limpiarListas()","recablea()" que en la clase madre se definen como abstractos """
            
    def init(self):
        """ Aqui se definen e inicializan los atributos particulares del algoritmo (atributos de cada nodo) """
        #self.coord=funciones.coordenadas(self.id)      # Mis coordenadas
        self.frec_enlaces = [0]*len(self.neighbors)     # Frecuencia de uso de los nodos vecinos
        self.frec_enlacesExtra = []     # Frecuencia de uso de mis enlaces extra
        self.frec_nodos = []       # Frecuencia de uso de los nodos que no son mis vecinos
        self.neighborsPerm = self.neighbors[:]    # Conjunto de vecinos permanentes
        self.extrasLibres = parametros.nEnlExt    # Número de enlaces extra que tengo libres
        self.idSolicitudEnlExtra = []     # Ids de los candidatos a ser mis vecinos por enlace extra y que aun no me contestan la peticion de conexión
        self.auxSolEnv = 0      # Contador de las solicitudes que he enviado para conectar mis enlaces extra
        self.idEnlaceExtra = [] # Ids de los vecinos que tengo conectados a un enlace extra
        self.paqEnviados = 0
        self.paqRegreso=0
        self.ciclo=1
        self.contPaq=0          # Contador de los paquetes que debo esperar
        self.terminoPaq=0       # Bandera que indica que termine mis paquetes y me pongo alerta a los PIF
        self.terminoRec=0       # Bandera que indica que termine de recablear mis enlaces y me pongo alerta a los PIF
        self.comRec=1           # Contador del PIF para comenzar la etapa de recableado
        self.padreRec=self.id
        self.visitadoR=False
        self.visitadoRPI=False
        self.comCiclo=1         # Contador del PIF para comenzar el nuevo ciclo
        self.padreCiclo=self.id
        self.contRecab=1        # Contador para saber en que paso estoy del recableado
        self.visitadoC=False
        self.visitadoCPI=False
        self.etapaRec=0         # 1 si estoy en etapa de recableado, 0 en otro caso
        self.rec=0              # Indica si ya acabe y tengo que responder a a mi padre el REWIRE-PIF
        self.cic=0              # Variable que indica si termine de recablear y puedo continuar el PIF
        self.bufferRec=[]       # Buffer de mensajes para comenzar el recableo
        self.numRec=0           # Número de reconexiones
        self.maxTray=0          # trayectoria maxima que siguieron mis paquetes
        self.iDesc=-1           # Guardo el id del nodo a quien envié un mensaje de desconexion// es igual a -1 cuando no he enviado una peticion de desconexion
        self.iConex=-1          # Guardo el id del nodo a quien meconectare en un recableado// es igual a -1 cuando no he enviado una peticion de conexion en recableado
        self.idsDesc=[]         # Aqui guardo los ids de quien me manda peticion de desconexion
        self.pifsCiclo=[]       # Ids de los nodos que me enviaron pifs para sincronizar ciclos 

    def limpiarListas(self):
        """Limpia las listas definidas en init para comenzar un nuevo ciclo"""
        del self.frec_enlaces[:]
        del self.frec_nodos[:]
        self.frec_enlaces = [0]*len(self.neighbors)
        del self.frec_enlacesExtra[:]
        del self.idsDesc[:]
        del self.idSolicitudEnlExtra[:]

    """def burbujaFrec_Nodos(self):
        for i in range(1,len(self.frec_nodos[0])):
            for j in range(0,len(self.frec_nodos[0])-i):
                if(self.frec_nodos[1][j] < self.frec_nodos[1][j+1]):
                    k=self.frec_nodos[1][j+1]
                    ik =self.frec_nodos[0][j+1]
                    self.frec_nodos[1][j+1] = self.frec_nodos[1][j]
                    self.frec_nodos[0][j+1] = self.frec_nodos[0][j]
                    self.frec_nodos[1][j] = k
                    self.frec_nodos[0][j] = ik
    """
    def recablea(self,event):
        """Se definen los mecanismos de recableado"""
        self.etapaRec=1             #Bandera que indica que estoy dentro de la etapa de recableado
        if len(self.bufferRec)>0:   #Si tengo mensajes en mi buffer los atiendo
            for i in range(len(self.bufferRec)):
                mBuffer=self.bufferRec[i]
                if mBuffer[0][1] == "D":
                    if (mBuffer[0][2] in self.neighbors) and (mBuffer[0][2] not in (self.idEnlaceExtra)) and (mBuffer[0][2] not in (self.neighborsPerm)):
                        
                        self.idsDesc.append(mBuffer[0][2])
                        newevent = Event([["R-ACK","D",self.id,"SI",mBuffer[0][3],mBuffer[0][4],"enLista"],[]],event.getTime() + 1.0,mBuffer[0][2],self.id)
                        self.transmit(newevent)
                    else:  
                        newevent = Event([["R-ACK","D",self.id,"NO",mBuffer[0][3],mBuffer[0][4],0],[]],event.getTime() + 1.0,mBuffer[0][2],self.id)
                        self.transmit(newevent)

                elif mBuffer[0][1] == "C":   
                    if ((mBuffer[0][2] not in self.neighbors)and ((mBuffer[0][2] not in self.idSolicitudEnlExtra) or ((mBuffer[0][2] in self.idSolicitudEnlExtra) and  (mBuffer[0][2]<self.id)))):
                        self.neighbors.append(mBuffer[0][2])
                        self.frec_enlaces.append(0) 
                        
                        if (mBuffer[0][2] in self.idSolicitudEnlExtra) and (mBuffer[0][2]<self.id):
                            #elimino el id del nodo de mis solicitudes enviadas
                            self.idSolicitudEnlExtra.remove(mBuffer[0][2]) 
                            
                        newevent = Event([["R-ACK","C",self.id,"SI"],[]],event.getTime()+ 1.0,mBuffer[0][2],self.id)
                        self.transmit(newevent)
                        
                    else:
                        newevent = Event([["R-ACK","C",self.id,"NO"],[]],event.getTime()+ 1.0,mBuffer[0][2],self.id)
                        self.transmit(newevent)

            del self.bufferRec[:]

        self.contRecab-=1
        
        #Si tengo enlaces extra sin usar conecto al nodo más visitado en la ronda de envio de paquetes
        if (self.extrasLibres > 0):
            #self.burbujaFrec_Nodos()    # Ordeno mi frecuencia de nodos de forma descendente

            self.frec_nodos.sort(key=lambda x:x[1], reverse = True) # Ordeno la lista de frecuencias
            while ((self.extrasLibres > self.auxSolEnv) and (len(self.frec_nodos)>=self.auxSolEnv)):
                #print self.id,":extras libres ",self.extrasLibres,"self.auxSolEnv=",self.auxSolEnv
                if((self.frec_nodos[self.auxSolEnv][0] not in self.neighbors) and (funciones.distancia(self.id,self.frec_nodos[self.auxSolEnv][0])<=parametros.tamEnlace)):
                    #agrego el id del nodo a la lista de solicitudes enviadas
                    self.idSolicitudEnlExtra.append(self.frec_nodos[self.auxSolEnv][0]) 
                    #Envio petición de conexión 
                    #print "Soy ", self.id, "envio peticion de enlace extra a ",self.frec_nodos[0][self.auxSolEnv], "idSolicitudEnlExtra=",self.idSolicitudEnlExtra
                    newevent = Event([["R","C",self.id],[]], event.getTime()+1.0, self.frec_nodos[self.auxSolEnv][0], self.id)
                    self.transmit(newevent)
                    if self.contRecab==0:
                        self.contRecab+=1
                self.auxSolEnv+=1
        else:
            #Busco el nodo mas visitado
            if self.frec_nodos!=[] and self.frec_enlaces!=[]:
                #Busco el 1er nodo mas visitado
                indMax=self.frec_nodos.index(max(self.frec_nodos, key=lambda x:x[1]))
                max1=int(self.frec_nodos[indMax][0])        ##quitar
     
            # Busco el enlace menos usado
            for x in range(len(self.idEnlaceExtra)): 
                indX=self.neighbors.index(self.idEnlaceExtra[x])
                self.frec_enlacesExtra.append(self.frec_enlaces[indX])
            indMin=self.frec_enlacesExtra.index(min(self.frec_enlacesExtra))

            # Reviso si puedo hacer el recableado
            if((int(self.frec_nodos[indMax][1])>=parametros.frecNodo) and (max1 not in self.neighbors) and (funciones.distancia(self.id,max1)<=parametros.tamEnlace)):
                #"R,D,"+str(self.id)+",C,"+str(max1)
                self.iDesc=self.idEnlaceExtra[indMin]
                self.iConex=max1
                newevent = Event([["R","D",self.id,"C",max1],[]], event.getTime()+1.0, self.iDesc, self.id)
                self.transmit(newevent)
                self.contRecab+=1
                #print self.id,"PeticionRecableado contRecab=",self.contRecab, " Desconecto=",self.iDesc," Conecto=",self.iConex        
        
        if (self.contRecab==0 and self.terminoRec==0):  #Si ya termine de recablear
            self.terminoRec=1
            #print "Soy ",self.id," termine mi recableado en recablea ciclo = ",self.ciclo, "vecinos=",self.neighbors     
            if self.id == parametros.coordinador:   #Si soy el coordinador comienzo el PIF para recablear
                
                newevent = Event([["CICLO","PIF",0],[]], event.getTime() + 1.0,self.id, self.id)
                self.transmit(newevent)
            if self.visitadoC==True and self.cic==0:
                self.cic=1  #Activo mi bandera para indicar que estoy dentro del PIF                
                for n in self.neighbors:
                    if n != self.padreCiclo:			
                        newevent = Event([["CICLO","PIF",0],[]], event.getTime()+1.0,n, self.id)
                        self.transmit(newevent)
                        self.comCiclo += 1
                        #print "Soy ",self.id, "envio CICLO,PIF a ",n ," comCiclo=",self.comCiclo," padreCiclo= ",self.padreCiclo
                if self.comCiclo == 0:   
                    if (self.id != parametros.coordinador):
                        #print self.id,":termino  numRec=",self.numRec," envio mi respuesta a ",self.padreCiclo
                        newevent = Event([["CICLO","PIF",self.numRec],[]], event.getTime()+1.0, self.padreCiclo, self.id)   
                    else:
                        print self.id,":termino  numRec=",self.numRec," envio mensaje de PI a ",self.padreCiclo
                        newevent = Event([["CICLO","PI"],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                    self.transmit(newevent)

    def receive(self, event):
        """ Aqui se definen las acciones concretas que deben ejecutarse cuando se
        recibe un evento """
        M=event.getName()       # Recibo el mensaje
        if M[0][0] == "START":  ##Comienzo el envio de un paquete. M[0][0]=="START"
            self.contPaq=self.contPaq+1
            new_package=funciones.newPackage(self.id)
            newM=[new_package[:],[]]
            next = funciones.Compass_Routing(self.id,self.neighbors,new_package[2],new_package[5:])    
            newevent = Event(newM, event.getTime() + 1.0, next, self.id)            
            self.transmit(newevent)
            self.paqEnviados=self.paqEnviados+1
            #print "START "+str(self.id)+":Envio-",new_package," t = ",event.getTime()," Ciclo=",self.ciclo, "Cont_paq=",self.contPaq
            
        if M[0][0] == "P":
            if (M[0][2] != self.id):
                
                auxN=self.neighbors[:]
                #print "P-",self.id," fuente=",event.getSource()," vecinos=",self.neighbors
                auxN.remove(event.getSource())         #Creo una copia de mi lista de vecinos
                for n in M[1]: #Descarto de la copia a todos los vecinos por los que ya paso el paquete
                    if n in auxN:
                        auxN.remove(n)

                ruta =M[0][5:]
                for m in ruta:
                    if m in auxN:
                        auxN.remove(m)
                #Comenzando backtraking 
                if len(auxN) == 0:              #Si la lista queda vacia entonces me agrego a la lista de nodos que no llevan al destino
                    M[1].append(self.id)
                    #Envio el paquete regreso a la fuente(o mi padre)
                    B=[M[0][:],M[1][:]]
                    B[0][0]="B"
                    newevent = Event(B, event.getTime() + 1.0,event.getSource(),self.id)
                    self.transmit(newevent)
                    #print "Backtrack ",self.id,"regreso el paquete a ",event.getSource(),": ",M," t= ",event.getTime(), " Ciclo= ",self.ciclo," Cont_paq= ",self.contPaq

                else:
                    self.contPaq=self.contPaq+1
                    next = funciones.Compass_Routing(self.id,auxN,M[0][2],ruta)
                    M[0].append(self.id)
                    newevent = Event(M, event.getTime() + 1.0,next,self.id)
                    self.transmit(newevent)
                    #print "Reenvio ",self.id,": ",M[0]," t= ",event.getTime(), " Ciclo= ",self.ciclo," Cont_paq= ",self.contPaq
            else:
                #Envio el paquete de vuelta al nodo origen 
                newM=[M[0][:],M[1][:]]
                newM[0].append(self.id)
                ruta = newM[0][5:]
                newM[0][0]="ACK"
                #print "LLego ",self.id,": llego al destino el paquete-",M[0]
                newevent = Event(newM, event.getTime() + 1.0, ruta[len(ruta)-2], self.id)
                self.transmit(newevent)

        if M[0][0] == "B": #Backtrack  
            auxN=self.neighbors[:]      #Creo una copia de mi lista de vecinos
            if self.id != M[0][1]:
                if M[0][len(M[0])-1] in auxN:
                    auxN.remove(M[0][len(M[0])-1])       #Borro de la lista a mi "padre" 
            
            for n in M[1]: #Descarto de la copia a todos los vecinos por los que ya paso el paquete
                if n in auxN:
                    auxN.remove(n)

            ruta =M[0][5:]
            for m in ruta:
                if m in auxN:
                    auxN.remove(m)
             
            if len(auxN) == 0:            #Si la lista queda vacia entonces me agrego a la lista de nodos que no llevan al destino
                self.contPaq=self.contPaq-1
                if self.id == M[0][1]:
                    #print "NO RUTA PARA -",M
                    self.paqRegreso=self.paqRegreso+1
                    if(self.paqRegreso  < parametros.num_paquetes):
                        newevent = Event([["START",self.id],[]], event.getTime() + 1.0,self.id,self.id)
                        self.transmit(newevent)
                else:
                    if self.id==M[0][len(M[0])-1]:
                        del M[0][len(M[0])-1]   
                    M[1].append(self.id)
                    #Envio el paquete regreso a la fuente(o mi padre)
                    newevent = Event(M, event.getTime() + 1.0,M[0][len(M[0])-1],self.id)
                    self.transmit(newevent)
                    #print "Backtrack(b) ",self.id,"regreso el paquete a ",event.getSource(),": ",M," t= ",event.getTime(), " Ciclo= ",self.ciclo," Cont_paq= ",self.contPaq

                #Verifico si ya termine de enviar mis paquetes

                if (self.contPaq==0 and self.paqRegreso == parametros.num_paquetes and self.terminoPaq==0):
                    self.terminoPaq=1
                    #print "TerminePaquetes ",self.id,": t= ",event.getTime(),"  Ciclo= ",self.ciclo
                    if (self.id==parametros.coordinador):
                        #print "Soy ",self.id, " comienza REWIRE,PIF"
                        #Si soy el coordinador comienzo el PIF para recablear
                        newevent = Event([["REWIRE","PIF",0],[]], event.getTime() + 1.0,self.id, self.id)
                        self.transmit(newevent)
                    if (self.visitadoR==True and self.rec==0):      
                        self.rec=1
                        for n in self.neighbors:
                            if n != self.padreRec:
                                #print "Soy ",self.id, "recibo REWIRE,PIF de ",event.getSource() ,"envio REWIRE,PIF a ",n			
                                newevent = Event([["REWIRE","PIF",0],[]], event.getTime()+1.0,n, self.id)
                                self.transmit(newevent)
                                self.comRec += 1
                        
                        if self.comRec == 0:
                            if (self.id != parametros.coordinador):
                                #print "Soy ",self.id,"termine, envio REWIRE,PIF a ",self.padreRec
                                newevent = Event([["REWIRE","PIF",self.maxTray],[]], event.getTime()+1.0, self.padreRec, self.id)
                            else:
                                #print "Soy ",self.id,"termine, envio REWIRE,PI a ",self.padreRec
                                newevent = Event([["REWIRE","PI"],[]], event.getTime()+1.0, self.padreRec, self.id)
                            self.transmit(newevent)
                          

            else:
                P=[M[0][:],M[1][:]]
                P[0][0]="P"
                next = funciones.Compass_Routing(self.id,auxN,M[0][2],ruta)
                newevent = Event(P, event.getTime() + 1.0,next,self.id)
                self.transmit(newevent)
                #print "Reenvio(b) ",self.id,": ",P[0]," t= ",event.getTime(), " Ciclo= ",self.ciclo," Cont_paq= ",self.contPaq
            

        if M[0][0] == "ACK":
            self.contPaq-=1
            if((M[0][1])==self.id):
                self.paqRegreso=self.paqRegreso+1
                ruta = M[0][6:]
                #print "*LlegoACK ",self.id,": ",M[0]," t=",event.getTime() ," Ciclo= ",self.ciclo, " Cont_paq= ",self.contPaq, " P-regreso: ",self.paqRegreso
                if len(ruta)>self.maxTray:
                    self.maxTray=len(ruta)
                k=self.neighbors.index(ruta[0])
                self.frec_enlaces[k] = self.frec_enlaces[k] + 1
                ##--------------------------------------------------
                ##--------------->Aqui me quedé<--------------------
                ##--------------------------------------------------
                indN=-1
                for i in range(1,len(ruta)):
                    for idn in range(0,len(self.frec_nodos)):
                        if self.frec_nodos[idn][0]==ruta[i]:
                            indN=idn
                        break
                    if indN!=-1:
                        self.frec_nodos[indN][1]+=1        
                    else:
                        self.frec_nodos.append([ruta[i],1])
                                        
                if(self.paqRegreso < parametros.num_paquetes):
                    newevent = Event([["START",self.id],[]], event.getTime() + 1.0,self.id,self.id)
                    self.transmit(newevent)           
            else:
                ruta = M[0][5:]
                indice=ruta.index(self.id)
                newevent = Event(M, event.getTime() + 1.0, ruta[indice-1], self.id)
                self.transmit(newevent)
                #print "ReenvioACK",self.id,": ",M[0]," t=",event.getTime() ," Ciclo= ",self.ciclo, " Cont_paq= ",self.contPaq

            if (self.contPaq==0 and self.paqRegreso == parametros.num_paquetes and self.terminoPaq==0):
                self.terminoPaq=1
                #print "TerminePaquetes ",self.id,": t= ",event.getTime(),"  Ciclo= ",self.ciclo
                if (self.id==parametros.coordinador):
                    #print "Soy ",self.id, " comienza REWIRE,PIF"
                    #Si soy el coordinador comienzo el PIF para recablear
                    newevent = Event([["REWIRE","PIF",0],[]], event.getTime() + 1.0,self.id, self.id)
                    self.transmit(newevent)
                if (self.visitadoR==True and self.rec==0):      
                    self.rec=1
                    for n in self.neighbors:
                        if n != self.padreRec:
                            #print "Soy ",self.id, "recibo REWIRE,PIF de ",event.getSource() ,"envio REWIRE,PIF a ",n			
                            newevent = Event([["REWIRE","PIF",0],[]], event.getTime()+1.0,n, self.id)
                            self.transmit(newevent)
                            self.comRec += 1
                    
                    if self.comRec == 0:
                        if (self.id != parametros.coordinador):
                            #print "Soy ",self.id,"termine, envio REWIRE,PIF a ",self.padreRec
                            newevent = Event([["REWIRE","PIF",self.maxTray],[]], event.getTime()+1.0, self.padreRec, self.id)
                        else:
                            print "Soy ",self.id,"termine, envio REWIRE,PI a ",self.padreRec, "MaxTray= ",self.maxTray
                            newevent = Event([["REWIRE","PI"],[]], event.getTime()+1.0, self.padreRec, self.id)
                        self.transmit(newevent)
                     
                
        """Sincronizacion para comenzar la etapa de recableado"""
        if M[0][0] == "REWIRE":
            if M[0][1]=="PIF":
                self.comRec-=1
                if self.visitadoR==False:
                    self.visitadoR = True
                    self.padreRec = event.getSource()
                    if (self.paqRegreso == parametros.num_paquetes and self.terminoPaq==1):
                        self.rec=1 
                        for n in self.neighbors:
                            if n != self.padreRec:
                                #print "Soy ",self.id, "recibo REWIRE,PIF de ",event.getSource() ,"envio REWIRE,PIF a ",n
                                newevent = Event([["REWIRE","PIF",0],[]], event.getTime()+1.0,n, self.id)
                                self.transmit(newevent)
                                self.comRec += 1
                
                if event.getSource()!=self.padreCiclo:  #Realizamos la sumatoria de el numero de cambios
                    if M[0][2]>self.maxTray:
                        self.maxTray=M[0][2]

                if self.comRec == 0 and self.terminoPaq==1:
                    if (self.id != parametros.coordinador):
                        #print "Soy ",self.id,"termine, envio REWIRE,PIF a ",self.padreRec
                        newevent = Event([["REWIRE","PIF",self.maxTray],[]], event.getTime()+1.0, self.padreRec, self.id)
                    else:
                        print "Soy ",self.id,"termine, envio REWIRE,PI a ",self.padreRec, "MaxTray= ",self.maxTray
                        newevent = Event([["REWIRE","PI"],[]], event.getTime()+1.0, self.padreRec, self.id)
                    self.transmit(newevent)
                
            if M[0][1]=="PI":
                if self.visitadoRPI == False:
                    self.visitadoRPI = True
                    self.visitadoC = False
                    self.visitadoCPI=False
                    self.comCiclo=1
                    self.cic=0
                    
                    #print self.id,": Comienzo el recableado t=",event.getTime() , " aviso -",self.neighbors                  
                    for n in self.neighbors:
                        newevent = Event([["REWIRE","PI"],[]], event.getTime()+1.0, n, self.id)
                        self.transmit(newevent)       
                    self.recablea(event)

        """Sincronizacion para comenzar el siguiente ciclo"""
        if M[0][0]=="CICLO":
            if M[0][1]=="PIF":
                self.comCiclo-=1
                if (self.terminoRec==0):
                    self.pifsCiclo.append(event.getSource())
                #print "CICLO-PIF Soy ",self.id," recibi CICLO,PIF de ",event.getSource()," comCiclo= ",self.comCiclo
                if self.visitadoC == False:
                    self.visitadoC = True
                    self.contPaq=0
                    self.paqEnviados=0
                    self.paqRegreso=0
                    self.padreCiclo = event.getSource()
                    #print "Soy ",self.id, " recibo CICLO,PIF de ",self.padreCiclo
                    if (self.contRecab==0 and self.terminoRec==1):
                        self.cic=1 #Activo mi bandera para indicar que estoy dentro del PIF                 
                        for n in self.neighbors:
                            if n != self.padreCiclo: 			
                                newevent = Event([["CICLO","PIF",0],[]], event.getTime()+1.0,n, self.id)
                                self.transmit(newevent)
                                self.comCiclo += 1
                                #print "Soy ",self.id, "envio CICLO,PIF a ",n ," comCiclo=",self.comCiclo," padreCiclo= ",self.padreCiclo
                if event.getSource()!=self.padreCiclo:  #Realizamos la sumatoria de el numero de cambios
                        self.numRec=self.numRec+M[0][2]
                      
                if (self.comCiclo == 0 and self.terminoRec==1):
                    if (self.id != parametros.coordinador):
                        #print self.id,":termino  numRec=",self.numRec," envio mi respuesta a ",self.padreCiclo
                        newevent = Event([["CICLO","PIF",self.numRec],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                    else:
                        print self.id,":termino "," envio mensaje de CICLO,PI a ",self.padreCiclo, " NumRecAcum= ",self.numRec
                        newevent = Event([["CICLO","PI"],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                    self.transmit(newevent)
                        
            if M[0][1]=="PI":
                if self.visitadoCPI == False:
                    #Aqui el coordinador debe revisar la variable self.numRec y ejecutar la condicion de paro
                    if self.ciclo<parametros.ciclos:                    
                        self.visitadoCPI = True
                        self.rec=0
                        self.visitadoR = False
                        self.visitadoRPI = False
                        self.etapaRec=0
                        self.contRecab=1
                        self.comRec=1
                        self.terminoPaq=0
                        self.terminoRec=0
                        self.numRec=0
                        self.maxTray=0
                        self.iDesc= -1
                        self.iConex= -1
                        self.auxSolEnv=0
                        self.limpiarListas()
                        #print self.id,"Puedo comenzar el nuevo ciclo tiempo=",event.getTime()," ciclo=",self.ciclo
                        self.ciclo+=1
                        for n in self.neighbors:
                            newevent = Event([["CICLO","PI"],[]], event.getTime()+1.0, n, self.id)
                            self.transmit(newevent)
                        ##---Aqui envio mensaje a mi mismo para comenzar el siguiente ciclo---##
                        newevent = Event([["START",self.id],[]], event.getTime() + 1.0,self.id,self.id)
                        self.transmit(newevent)

        if M[0][0] == "R":
            if(self.etapaRec==0):
                #Si no estoy en etapa de recableado guardo la peticion en el buffer 
                self.bufferRec.append(M)
            else:
                ## Recibo mensaje de desconexion
                if M[0][1] == "D":
                    #print self.id,"=",M
                    ## Recibo peticion de desconexion
                    if M[0][3] =="C":

                        if ((event.getSource() in self.neighbors) and (event.getSource() not in (self.idEnlaceExtra)) and (event.getSource() not in (self.neighborsPerm))):
                            self.idsDesc.append(event.getSource())
                            newevent = Event([["R-ACK","D",self.id,"SI",M[0][3],M[0][4],"enLista"],[]],event.getTime() + 1.0,event.getSource(),self.id)
                        else:
                            newevent = Event([["R-ACK","D",self.id,"NO",M[0][3],M[0][4],],[]],event.getTime() + 1.0,event.getSource(),self.id)

                        self.transmit(newevent)
                     

                    ## Recibo cancelacion de desconexion
                    elif M[0][3] == "cancelar":
                        self.idsDesc.remove(event.getSource())
                    
                ## Recibo mensaje de conexion        
                elif M[0][1]== "C":
                    if ((event.getSource() not in self.neighbors)and ((event.getSource() not in self.idSolicitudEnlExtra) or ((event.getSource() in self.idSolicitudEnlExtra) and  (event.getSource()<self.id)))):
                        self.neighbors.append(event.getSource())
                        self.frec_enlaces.append(0) 
                        if (event.getSource() in self.idSolicitudEnlExtra) and  (event.getSource()<self.id):
                            #elimino el id del nodo de mis solicitudes enviadas
                            self.idSolicitudEnlExtra.remove(event.getSource())
                        newevent = Event([["R-ACK","C",self.id,"SI"],[]],event.getTime()+ 1.0,event.getSource(),self.id)
                        self.transmit(newevent)
                        if self.cic==1:
                            self.comCiclo += 1
                            newevent = Event([["CICLO","PIF",0],[]], event.getTime()+1.0,event.getSource(), self.id)
                            self.transmit(newevent)
                            
                            #print self.id,": recibi peticion de ",event.getSource()," envio PIF comCiclo=",self.comCiclo," vecinos=",self.neighbors
                    else:
                        newevent = Event([["R-ACK","C",self.id,"NO"],[]],event.getTime()+ 1.0,event.getSource(),self.id)
                        self.transmit(newevent)

        if M[0][0] == "R-ACK": 
            if M[0][1] == "D":
                if M[0][3]=="NO":
                   self.contRecab-=1
                elif M[0][3]=="SI":
                    
                    if M[0][6]== "enLista": #el nodo que me contesta si puede borrarme de sus vecinos
                        #print self.id,"recibo enlista desde ",event.getSource()
                        if M[0][5] not in self.neighbors:
                            self.idSolicitudEnlExtra.append(M[0][5])
                            newevent = Event([["R","C",self.id],[]], event.getTime()+1.0, M[0][5], self.id)
                            #print self.id, "estoy en la lista de ",event.getSource()
                            self.numRec+=1
                            self.transmit(newevent)
                            
                        else:
                            self.contRecab-=1
                            #print self.id, " envio cancelar a ",self.iDesc
                            newevent = Event([["R","D",self.id,"cancelar"],[]], event.getTime()+1.0, self.iDesc, self.id)
                            self.transmit(newevent)
                    elif M[0][6]== "borrado":
                        self.contRecab-=1
                        indVec=self.neighbors.index(event.getSource())
                        del self.neighbors[indVec]
                        del self.frec_enlaces[indVec]
                        #print "R-ACK:soy ",self.id," borre mi enlace con ",event.getSourc
                        self.idEnlaceExtra.remove(event.getSource())
                        if event.getSource() in self.pifsCiclo:
                            #print self.id,":mi lista fatatas= ",self.pifsCiclo
                            self.comCiclo+=1
                        print "r ",self.id," ",self.iDesc," ",self.iConex," ",self.ciclo
                    ## Recibo confirmacion de desconexion
                    elif M[0][6] == "confirmacion":
                        indVec=self.neighbors.index(event.getSource())
                        del self.neighbors[indVec]
                        del self.frec_enlaces[indVec]
                        self.idsDesc.remove(event.getSource())
                        if self.cic==1:
                            self.comCiclo-=1
                            if self.comCiclo == 0:
                                if (self.id != parametros.coordinador):
                                    #print self.id,":termino numRec=",self.numRec," envio mi respuesta a ",self.padreCiclo
                                    newevent = Event([["CICLO","PIF",self.numRec],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                                else:
                                    print self.id,":termino numRec=",self.numRec," envio mensaje de PI a ",self.padreCiclo
                                    newevent = Event([["CICLO","PI"],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                                self.transmit(newevent)
                        #print self.id," recibo confirmacion de ",event.getSource()," envio borrado a ",event.getSource()
                        newevent = Event([["R-ACK","D",self.id,"SI",0,0,"borrado"],[]],event.getTime() + 1.0,event.getSource(),self.id)
                        self.transmit(newevent)
                    
      
            if M[0][1] == "C":
                if M[0][3]=="SI":
                    ## Recibo R-ACK,C,SI para conectarme a event.getSource()
                    self.neighbors.append(event.getSource())
                    self.frec_enlaces.append(0)
                    
                    if event.getSource() in self.idSolicitudEnlExtra:
                        self.idEnlaceExtra.append(event.getSource())
                        self.idSolicitudEnlExtra.remove(event.getSource())
                               
                    if self.iConex == -1:
                        self.contRecab-=1
                        print "c ",self.id," ",-1," ",event.getSource()," ",self.ciclo
                        self.extrasLibres=self.extrasLibres-1
                        
                    elif (event.getSource() == self.iConex) and (self.numRec>0):
                        #print self.id, " envio confirmacion a ",self.iDesc
                        newevent = Event([["R-ACK","D",self.id,"SI",0,0,"confirmacion"],[]], event.getTime()+1.0, self.iDesc,self.id)
                        
                        self.transmit(newevent)
                        if (self.visitadoC==True and self.cic==0):
                            
                            if self.iDesc==self.padreCiclo:
                                self.padreCiclo=self.id
                                self.visitadoC==False
                                self.comCiclo+=1
                                #print self.id,": borre a ",self.iDesc, " como mi padre ahora mi padre es ",event.getSource()," comCiclo=",self.comCiclo
                                            
                elif M[0][3]=="NO":
                    ## Recibo R-ACK,C,NO para cancelar mi conexion al nodo fuente
                    if event.getSource() in self.idSolicitudEnlExtra:
                        self.idSolicitudEnlExtra.remove(event.getSource())
                    self.contRecab-=1
                    if event.getSource() == self.iConex and (self.numRec>0):
                        self.numRec-=1
                        newevent = Event([["R","D",self.id,"cancelar"], []], event.getTime()+1.0, self.iDesc, self.id)
                        #print self.id, " envio cancelar a ",self.iDesc
                        self.transmit(newevent)

                if (len(self.idSolicitudEnlExtra)>0) and (self.iConex== -1):
                    self.contRecab+=1
                    

            if (self.contRecab==0 and self.terminoRec==0):
                self.terminoRec=1
                del self.pifsCiclo[:]
                self.pifsCiclo=[]
                #print "Soy ",self.id," termine mi recableado en R-ACK ciclo = ",self.ciclo, "vecinos=",self.neighbors     
                if(self.id==parametros.coordinador):
                    #print "Soy ",self.id, " comienza CICLO,PIF"
                    #Si soy el coordinador comienzo el PIF para recablear
                    newevent = Event([["CICLO","PIF",0],[]], event.getTime() + 1.0,self.id, self.id)
                    self.transmit(newevent)

                if (self.visitadoC==True and self.cic==0):
                    self.cic=1 #Activo mi bandera para indicar que estoy dentro del PIF
                    for n in self.neighbors:
                        if n != self.padreCiclo:			
                            newevent = Event([["CICLO","PIF",0],[]], event.getTime()+1.0,n, self.id)
                            self.transmit(newevent)
                            self.comCiclo += 1
                            #print "Soy ",self.id, "envio CICLO,PIF a ",n ," comCiclo=",self.comCiclo," padreCiclo= ",self.padreCiclo
                    if self.comCiclo == 0:
                        if (self.id != parametros.coordinador):
                            #print self.id,":termino numRec=",self.numRec," envio mi respuesta a ",self.padreCiclo
                            newevent = Event([["CICLO","PIF",self.numRec],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                        else:
                            print self.id,":termino numRec=",self.numRec," envio mensaje de PI a ",self.padreCiclo
                            newevent = Event([["CICLO","PI"],[]], event.getTime()+1.0, self.padreCiclo, self.id)
                        self.transmit(newevent)


# ----------------------------------------------------------------------------------------
# "main()"
# ----------------------------------------------------------------------------------------

# construye una instancia de la clase Simulation recibiendo como parametros el nombre del 
# archivo que codifica la lista de adyacencias de la grafica y el tiempo max. de simulacion

if len(sys.argv) != 2:
    print "Please supply a file name"
    raise SystemExit(1)
experiment = Simulation(sys.argv[1], sys.maxint)  

# asocia un pareja proceso/modelo con cada nodo de la grafica

for i in range(1,len(experiment.graph)+1):
    m = simulacionRecableado()
    experiment.setModel(m, i)

# inserta un evento semilla en la agenda y arranca

seed=[]
for i in range(1,len(experiment.graph)+1):
    seed.append(Event([["START",i],[]], 0.0, i,i))
    experiment.init(seed[i-1])

experiment.run()
