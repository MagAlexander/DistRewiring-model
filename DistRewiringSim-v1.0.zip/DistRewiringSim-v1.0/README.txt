Rewiring software for shaping complex networks
