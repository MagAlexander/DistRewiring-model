# This Python file uses the following encoding: utf-8
"""Se crea una animación de la simulación en un archivo .gif
    Se calculan el coeficiente de agrupamiento, longitud de trayectoria promedio y el diámetro de la red"""
import sys
import parametros
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.animation as animation

if len(sys.argv) != 3:
    print "Please supply a file name"
    raise SystemExit(1)


f=open(sys.argv[1],'r')
fd=open("datos-"+sys.argv[1],'w')

lines = f.readlines()
f.close()
G=nx.read_adjlist("espacio"+str(parametros.m)+"x"+str(parametros.n)+".adjlist",nodetype=int)
G2=nx.grid_2d_graph(parametros.n,parametros.m)
posicion = dict(zip(sorted(G),sorted(G2)))

plt.figure(num=None, figsize=(7, 7), dpi=500)
color=[float(G.degree(v)) for v in G]
size=[(float(G.degree(v))*2) for v in G]
nx.draw_networkx_nodes(G,posicion,node_color=color,alpha=0.8,node_size=size,with_labels=False)
nx.draw_networkx_edges(G,posicion,alpha=0.5,width=1.0)

plt.axis('off')
avCl=nx.average_clustering(G)
try:
    diam=nx.diameter(G)
    avSPL=nx.average_shortest_path_length(G)
except nx.exception.NetworkXError, error:
    H=nx.connected_component_subgraphs(G)[0]
    diam=nx.diameter(H)
    avSPL=nx.average_shortest_path_length(H)
    orden=H.order()
#nx.info(G)+
datos="\nD: "+str(diam)+"\nCA: "+str(avCl)+"\nLTP: "+str(avSPL)
plt.text(0, 0.9, datos,horizontalalignment='left',transform=plt.gca().transAxes)

plt.savefig("e00.svg")
k=1
cicloAnterior=str(0)
for line in lines:
    accion,fuente,desconecta,conecta,ciclo = line.split()
    if(ciclo!=cicloAnterior):
        nx.write_adjlist(G,"esp"+str(parametros.n)+"x"+str(parametros.m)+"_"+sys.argv[2]+"_"+cicloAnterior+".adjlist")
        fh=open("hist_"+sys.argv[2]+"_"+cicloAnterior+".txt",'w')
        hist=nx.degree_histogram(G)
        j=0
        for i in hist:
            fh.write(str(j)+'\t'+str(i)+'\n')
            j=j+1
        fh.close()

        color=[float(G.degree(v)) for v in G]
        size=[(float(G.degree(v)))*2 for v in G]
        nx.draw_networkx_nodes(G,posicion,node_color=color,alpha=0.8,node_size=size,with_labels=False)
        nx.draw_networkx_edges(G,posicion,alpha=0.5,width=1.0)

        avCl=nx.average_clustering(G)
        nCom=nx.number_connected_components(G)
        orden=G.order()
        try:
            diam=nx.diameter(G)
            avSPL=nx.average_shortest_path_length(G)
        except nx.exception.NetworkXError, error:
            H=nx.connected_component_subgraphs(G)[0]
            diam=nx.diameter(H)
            avSPL=nx.average_shortest_path_length(H)
            orden=H.order()

        datos="\nD: "+str(diam)+"\nCA: "+str(avCl)+"\nLTP: "+str(avSPL)

        fd.write(cicloAnterior+'\t')
        fd.write(str(avCl)+'\t')
        fd.write(str(nCom)+'\t')
        fd.write(str(diam)+'\t')
        fd.write(str(avSPL)+'\t')
        fd.write(str(orden)+'\n')

        cicloAnterior=ciclo
        k=k+1
    
    if (accion=="r"):
        
        if (int(fuente),int(desconecta)) in G.edges():
            G.remove_edge(int(fuente),int(desconecta))
        elif (int(desconecta),int(fuente)) in G.edges():
            G.remove_edge(int(desconecta),int(fuente))
    
    if (int(fuente),int(conecta)) not in G.edges():
	    G.add_edge(int(fuente),int(conecta))
    elif (int(conecta),int(fuente)) not in G.edges():
        G.add_edge(int(conecta),int(fuente))

plt.clf()
plt.figure(num=None, figsize=(7, 7), dpi=500)
color=[float(G.degree(v)) for v in G]
size=[(float(G.degree(v))*2) for v in G]
nx.draw_networkx_nodes(G,posicion,node_color=color,alpha=0.8,node_size=size,with_labels=False)
nx.draw_networkx_edges(G,posicion,alpha=0.5,width=1.0)

plt.title("Red de "+str(parametros.m*parametros.n)+" nodos (C0-Todos-Diag/16)")


plt.axis('off')
avCl=nx.average_clustering(G)
nCom=nx.number_connected_components(G)
orden=G.order()
try:
    diam=nx.diameter(G)
    avSPL=nx.average_shortest_path_length(G)
except nx.exception.NetworkXError, error:
    H=nx.connected_component_subgraphs(G)[0]
    diam=nx.diameter(H)
    avSPL=nx.average_shortest_path_length(H)
    orden=H.order()
#nx.info(G)+
datos="\nD: "+str(diam)+"\nCA: "+str(avCl)+"\nLTP: "+str(avSPL)

fd.write(cicloAnterior+'\t')
fd.write(str(avCl)+'\t')
fd.write(str(nCom)+'\t')
fd.write(str(diam)+'\t')
fd.write(str(avSPL)+'\t')
fd.write(str(orden)+'\n')
fh=open("hist_"+sys.argv[2]+"f_"+cicloAnterior+".txt",'w')
hist=nx.degree_histogram(G)
j=0
for i in hist:
    fh.write(str(j)+'\t'+str(i)+'\n')
    j=j+1
fh.close()
plt.text(0, 0.9, datos,horizontalalignment='left',transform=plt.gca().transAxes)
plt.savefig("e%02d.svg" % k)

fd.close()
nx.write_adjlist(G,"esp"+str(parametros.n)+"x"+str(parametros.m)+"_"+sys.argv[2]+"f.adjlist")
