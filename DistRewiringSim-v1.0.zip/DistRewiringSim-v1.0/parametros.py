# This Python file uses the following encoding: utf-8
# Ultima fecha de modificacion: 13-11-2014
## Definicion de los parametros de la simulacion

import math

n = 50	            # Número de renglones de la malla inicial
m = 50

def diag():
    n1=[0,0]
    n2=[n-1,m-1]
    d=math.sqrt(math.pow(n2[0]-n1[0],2)+math.pow(n2[1]-n1[1],2))
    return d

	            # Número de columnas de la malla inicial
coordinador=1       # Identificador del coordinador
num_paquetes= 20	# Número de paquetes que envia cada nodo
ciclos=30           # Número de ciclos
diagonal=diag()     # Calculo el tamaño de la diagonal principal de la red
tamEnlace=diagonal  # Longitud máxima del enlace
maxEnlaces=(n*(n-1)*2)      # Número de enlaces soportados
frecEnlace = num_paquetes*0.1   # frecuencia de uso de enlace
frecNodo = num_paquetes*0.5     # frencuencia de uso de nodo
nEnlExt = 2                     # Número de enlaces extra
