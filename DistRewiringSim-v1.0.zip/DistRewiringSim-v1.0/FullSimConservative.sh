#!/bin/bash
echo "Start simulation"
python conservativeSim.py espacio10x10.txt > trace10x10_conservative-1.txt 
echo "Ends simulation"
echo "Data extraction begins"
python extractData.py trace10x10_conservative-1.txt  traceCon-1
echo "Data extraction ends"
