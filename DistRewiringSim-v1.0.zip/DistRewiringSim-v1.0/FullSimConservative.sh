#!/bin/bash
x=1
while [ $x -le 10 ]
do
    time python optimisticSim.py espacio50x50.txt > trace-$x.txt 
    echo "Ends simulacion $x"
x=$(( $x + 1 ))
done
