import parametros
import networkx as nx

renglones=parametros.m
columnas=parametros.n

G=nx.grid_2d_graph(renglones,columnas)
G=nx.convert_node_labels_to_integers(G,first_label=1,ordering="sorted")

nx.write_adjlist(G,"espacio"+str(renglones)+"x"+str(columnas)+".adjlist")

f=open("espacio"+str(renglones)+"x"+str(columnas)+".txt",'w')

for n in range(0,renglones*columnas):
	if(n>=columnas): #Vecino superior
		f.write(str(n-columnas+1)+' ')

	if((n%columnas)>0): #vecino izquierdo
		f.write(str(n)+' ')

	if(((n+1)%columnas)>0): #vecino derecho
		f.write(str(n+2)+' ')

	if((n<((renglones-1)*columnas))>0): #vecino inferior
		f.write(str(n+columnas+1)+' ')

	f.write('\n')

f.close()
