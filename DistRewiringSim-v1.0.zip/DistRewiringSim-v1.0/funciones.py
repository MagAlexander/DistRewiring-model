# This Python file uses the following encoding: utf-8
import parametros
import random
import math

def coordenadas(identificador):
    x=(identificador-1)%parametros.n
    y=(identificador-1)/parametros.m
    coord=[x,y]
    return coord

#Crea un nuevo mensaje a enviar
#formato del mensaje:
# P,fuente,destino,coordenadax,coordenaday,destino(iniciodelcamino)
def newPackage(identificador):
    d=False
    while(d==False):
        dest=random.randint(1, parametros.n*parametros.m)
        if dest!= identificador:
            d=True

    coorDest=coordenadas(dest)
    x=coorDest[0]
    y=coorDest[1]
    paq=["P", identificador,dest,x,y,identificador]
    #paq="P,"+str(identificador)+","+str(dest)+","+str(x)+","+str(y)+","+str(identificador)
    return paq

def distancia(nodo1,nodo2):
    n1=coordenadas(nodo1)
    n2=coordenadas(nodo2)
    d=math.sqrt(math.pow(n2[0]-n1[0],2)+math.pow(n2[1]-n1[1],2))
    return d

def angulo(destino,origen,nodo):
    p0=coordenadas(origen)
    p1=coordenadas(destino)
    p2=coordenadas(nodo)
    u1=p1[0]-p0[0]
    u2=p1[1]-p0[1]
    v1=p2[0]-p0[0]
    v2=p2[1]-p0[1]
    div=(math.fabs(u1*v1+u2*v2))/((math.sqrt((math.pow(u1,2) + math.pow(u2,2))))*(math.sqrt((math.pow(v1,2) + math.pow(v2,2)))))
    #print "div=",div, "type=",type(div),
 
    #print "origen=",origen," p0=",p0, " destino=",destino," p1=",p1, " nodo=",nodo," p2=",p2,"a=",math.fabs(u1*v1+u2*v2), " b=",(math.sqrt(math.pow(u1,2) + math.pow(u2,2)))*(math.sqrt(math.pow(v1,2) + math.pow(v2,2))) ,"div=",div,"type1=",type(1.0)," acos1=",math.acos(1.0),"acos=",math.acos((math.fabs(u1*v1+u2*v2))/((math.sqrt((math.pow(u1,2) + math.pow(u2,2))))*(math.sqrt((math.pow(v1,2) + math.pow(v2,2))))))

    try:
        angC=math.degrees(math.acos(div))
    except ValueError, error:
        if div>1.0:
            div=1.0
            #print "div es mayor que 1.0!!!!"
        elif div < -1.0:
            div=-1.0
            #print "div es menor que -1.0!!!!"
        angC=math.degrees(math.acos(div))

    
    if (p2[0]<p0[0]<p1[0])or(p2[0]>p0[0]>p1[0])or(p2[1]<p0[1]<p1[1])or(p2[1]>p0[1]>p1[1]):
        angC=180-angC
    
    #print "AnguloC",nodo,"=",angC        
    return angC

def Compass_Routing(identificador,vecinos,destino,ruta):
    v= identificador
    w=random.choice(vecinos)
    ang=360
    if destino in vecinos:
        indice=vecinos.index(destino)
        w=vecinos[indice]
    else:
        for i in range(0,len(vecinos)):     
            if vecinos[i] not in ruta:
                ang2=angulo(destino,identificador,vecinos[i]) 
                if ang2<=ang:
                    w=vecinos[i]
                    ang=ang2
    return w
